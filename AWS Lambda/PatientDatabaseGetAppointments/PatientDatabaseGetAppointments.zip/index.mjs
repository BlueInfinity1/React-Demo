import mysql from 'mysql2/promise';

export const handler = async (event) => {
    console.log("Received appointment fetch request:", event.queryStringParameters);

    // Extract query parameters
    const params = event.queryStringParameters || {};
    const doctor_id = params.doctor_id;
    const date = params.date || new Date().toISOString().split('T')[0]; // Default to today

    if (!doctor_id) {
        console.error("Missing required parameter: doctor_id");
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Missing required parameter: doctor_id" })
        };
    }

    const connection = await mysql.createConnection({
        host: 'patients-database-instance-1.cha680k884mq.us-east-1.rds.amazonaws.com', // Replace with actual host
        user: 'admin',
        password: 'LwWtkzuBVhyqsQ9wu7A1', // Replace with actual password
        database: 'patients_database'
    });

    try {
        console.log(`Fetching appointments for doctor ${doctor_id} on ${date}...`);

        const [appointments] = await connection.execute(
            `SELECT a.id, a.doctor_id, a.patient_id, p.name AS patient_name, a.start_time, a.created_at
             FROM appointments a
             JOIN patients p ON a.patient_id = p.id
             WHERE a.doctor_id = ? 
             AND DATE(a.start_time) = ?
             ORDER BY a.start_time ASC`,
            [doctor_id, date]
        );

        await connection.end();

        console.log(`Fetched ${appointments.length} appointments.`);

        return {
            statusCode: 200,
            body: JSON.stringify(appointments)
        };

    } catch (error) {
        console.error("Database Query Error:", error.message);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};
